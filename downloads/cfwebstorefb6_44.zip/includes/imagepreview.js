
<script language="JavaScript" type="text/javascript">
	<!--
	function openWin( windowURL, windowName, windowFeatures ) { 
		return window.open( windowURL, windowName, windowFeatures ) ; 
	} 
	
	function previewImg( windowURL, windowName, windowFeatures, textfield ) { 
		var image =  eval("document.editform." + textfield + ".value");
		var openURL = windowURL + "?Image=" + image;
		return window.open( openURL, windowName, windowFeatures ) ; 
	} 
	//-->
</script>