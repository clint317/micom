<script language="JavaScript">
	if (self != top) top.location.href = window.location.href;
</SCRIPT>
