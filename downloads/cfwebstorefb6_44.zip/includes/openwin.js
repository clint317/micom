
	function openWin( windowURL, windowName, windowFeatures ) { 
		return window.open( unescape(windowURL), windowName, windowFeatures ) ; 
	} 
