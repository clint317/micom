DOMinccfg={
// CSS classes
// trigger DOMinclude
  triggerClass:'DOMpop',
// class of the popup
  popupClass:'popup',
// class of the link when the popup 
// is open
  openPopupLinkClass:'popuplink',
// text to add to the link when the 
// popup is open 
  displayPrefix:'Hide ',
// filter to define which files should
// not open in an iframe
  imagetypes:'jpg|JPG|JPEG|jpeg|gif|GIF|png|PNG',
// dimensions of the popup
  frameSize:[320,180]
}
